def example_function(x):

    return x**2
